#!/usr/bin/env_python3
from brain_games.cli.cli import welcome_user


def main() -> None:
    welcome_user()


if __name__ == "__main__":
    main()
