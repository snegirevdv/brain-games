ROUNDS = 3
"""Amount of rounds in the game."""

LIMITS: tuple[int] = (1, 100)
"""Tuple of minimal and maximal random number."""
