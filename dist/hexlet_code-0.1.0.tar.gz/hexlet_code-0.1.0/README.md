### Branches
[![Actions Status](https://github.com/snegirevdv/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/snegirevdv/python-project-49/actions) [![Maintainability](https://api.codeclimate.com/v1/badges/b14f493ee4c8c3a94c85/maintainability)](https://codeclimate.com/github/snegirevdv/python-project-49/maintainability)

### How to use
[![asciicast](https://asciinema.org/a/KHEpZNAixxl0uqsaineMAs7Di.svg)](https://asciinema.org/a/KHEpZNAixxl0uqsaineMAs7Di)